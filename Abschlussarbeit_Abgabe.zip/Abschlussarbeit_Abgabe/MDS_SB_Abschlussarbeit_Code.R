## Abschlussarbeit: Medical Data Science ##

# Vorhersage der Hospitalisierungswahrscheinlichkeit zur Identifizierung potenzieller
# geriatrischer Diseasemanagementprogramm-Teilnehmer auf Basis gesundheitsbezogener
# Leistungsdaten

##### 1. Einleitung #####

##### 2. Gesundheitsbezogene Leistungsdaten #####
## Datensatz einlesen ## 
# Originaldatensatz: 1.131 Variablen und  102.111 Beobachtungen
# fiktiver Datensatz: Struktur-gleich, 10%: 1.131 Variablen und 10.211 Beobachtungen 

fiktiv_GzH_Daten <- read.csv("/home/shared_folders/health_sd_analytics/analytikleistung/GesundzuHause/MDS_Abschlussarbeit/fiktiv_GzH_Daten.csv")

data_in_dt <- data.table::data.table(fiktiv_GzH_Daten)

##### 3. Datenaufbereitung #####
##### 3.1 Variablenselektion #####
## 1. Schritt: Fachliche Selektion und Filterung ##
# VP unter 65 Jahren & a-posteriori Variablen entfernt
# Reduktion auf 1.122 Variablen
# Reduktion auf 91.989 Beobachtungen

# erste Selektion
geri_0 <- data_in_dt %>%
  filter(VP_ALTER >= 65) %>%
  select(-LST_LPAESBTR_1_STATARZT,
         -LST_LPAESBTR_1_STATGES,
         -LST_LPAESBTR_1_STATPFL,
         -LST_ANTBELEG_1_STATARZT,
         -LST_ANTBELEG_1_STATGES,
         -LST_ANTBELEG_1_STATPFL,
         -LST_BLGREBTR_1_STATARZT,
         -LST_BLGREBTR_1_STATGES,
         -LST_BLGREBTR_1_STATPFL,
         -STA_ANZ_STATAUFH_X_MIN_KHKAT,
         -STA_ANZ_STATAUFH_X_MAX_UNIKZ,
         -STA_ANZ_STAT_X_ANZ_VERSCHKH)

## 2. Schritt: Missings ##
# keine Werte entfernt
Missings <- geri_0 %>%
  summarise_all(list(~ sum(is.na(.)))) %>%
  t() %>%
  head(10) %>%
  kable(., caption = "Fig.29: Anzahl Missings pro Variable, ersten 10 von 1.119 Variablen") %>%
  kable_styling(latex_options = "striped", position = "center")

Missings

geri_1<- geri_0

## 3. Schritt: VS mit Random Forest ##
# Durchgänge vorbereiten
geri_1_2_550<- geri_1 %>%
  select(STA_IND_STATAUFENTH_RESP1,
         c(2:551))

geri_1_551_1119<- geri_1 %>%
  select(STA_IND_STATAUFENTH_RESP1,
         c(552:1119))

# Selection der wichtigsten zu erklärenden Variablen über RF
registerDoParallel()
# No. Cores: 96
no_cores <- detectCores()
# No. Cores parallel: 48
no_cores_par <- getDoParWorkers()
getDoParName()
getDoParVersion()

# Anzahl Bäume 20
anz_tree <- 20
anz_tree_pro_core <- ceiling(anz_tree / no_cores_par)
# Anzahl Bäume pro Core: 48
anz_tree_pro_core * no_cores_par

# GiniDecreaseGini: Durchgang1
ntree <- rep(anz_tree_pro_core , no_cores_par)

vs.rf.model_vs1 <-
  foreach(
    ntree = rep(anz_tree_pro_core , no_cores_par),
    .combine = randomForest::combine,
    .multicombine = TRUE,
    .packages = 'randomForest'
  ) %dopar% {
    set.seed(2022)
    randomForest(
      as.factor(STA_IND_STATAUFENTH_RESP1) ~.,
      geri_1_2_550,
      na.action = na.roughfix,
      importance = TRUE,
      ntree = ntree
    )
  }

# GiniDecreaseGini: Durchgang2
ntree <- rep(anz_tree_pro_core , no_cores_par)

vs.rf.model_vs2 <-
  foreach(
    ntree = rep(anz_tree_pro_core , no_cores_par),
    .combine = randomForest::combine,
    .multicombine = TRUE,
    .packages = 'randomForest'
  ) %dopar% {
    set.seed(2022)
    randomForest(
      as.factor(STA_IND_STATAUFENTH_RESP1) ~.,
      geri_1_551_1119,
      na.action = na.roughfix,
      importance = TRUE,
      ntree = ntree
    )
  }

# GiniDecreaseGini: Ergebnisse aus Durchgang 1 & 2
# 1. Vorgang
# varImpPlot(vs.rf.model_vs1, type = 2, bg = "#027180", cex=0.75, pch=21)
imp <- varImpPlot(vs.rf.model_vs1, type = 2, bg = "#027180", cex=0.75, pch=21)
imp <- as.data.frame(imp)
imp$varnames <- rownames(imp)
rownames(imp) <- NULL 
imp<- imp %>%
  head(10)

rf_varimp1<- ggplot(imp, aes(x=reorder(varnames, MeanDecreaseGini), y=MeanDecreaseGini)) + 
  geom_point() +
  geom_segment(aes(x=varnames,xend=varnames,y=0,yend=MeanDecreaseGini)) +
  theme_bw() +
  labs(
    title = "1. RF: Variablen Wichtigkeit",
    x= "Mean Decrease Gini",
    y= "Variable Name") +
  coord_flip()

rf_varimp1

x1 <- importance(vs.rf.model_vs1, type = 2, conditional = TRUE)
importanceOrder1 <- order(-x1)
namen1 <- rownames(x1)[importanceOrder1][1:550]

# 2. Vorgang
# varImpPlot(vs.rf.model_vs2, type = 2, bg = "#027180", cex=0.75, pch=21)
imp2 <- varImpPlot(vs.rf.model_vs2, type = 2, bg = "#027180", cex=0.75, pch=21)
imp2 <- as.data.frame(imp2)
imp2$varnames <- rownames(imp2)
rownames(imp2) <- NULL 
imp2<- imp2 %>%
  head(10)

rf_varimp2<- ggplot(imp2, aes(x=reorder(varnames, MeanDecreaseGini), y=MeanDecreaseGini)) + 
  geom_point() +
  geom_segment(aes(x=varnames,xend=varnames,y=0,yend=MeanDecreaseGini)) +
  theme_bw() +
  labs(
    title = "2. RF: Variablen Wichtigkeit",
    x= "Mean Decrease Gini",
    y= "Variable Name") +
  coord_flip()

rf_varimp2

x2 <- importance(vs.rf.model_vs2, type = 2, conditional = TRUE)
importanceOrder2 <- order(-x2)
namen2 <- rownames(x2)[importanceOrder2][1:568]

# 1. & 2. Vorgang für 3. Lauf mit jeweils 250 besten Variaben
name1_vs <- rownames(x1)[importanceOrder1][1:250]
name2_vs <- rownames(x2)[importanceOrder2][1:250]
name_vs <- union(name1_vs, name2_vs) 

# Auswahl der jeweils besten 250 (ges. 500) aus Datensatz
geri_1_b500<- geri_1 %>%
  select(STA_IND_STATAUFENTH_RESP1,
         !!!name_vs)

# GiniDecreaseGini: Durchgang3

vs.rf.model_vs3 <-
  foreach(
    ntree = rep(anz_tree_pro_core , no_cores_par),
    .combine = randomForest::combine,
    .multicombine = TRUE,
    .packages = 'randomForest'
  ) %dopar% {
    set.seed(2022)
    randomForest(
      as.factor(STA_IND_STATAUFENTH_RESP1) ~.,
      geri_1_b500,
      na.action = na.roughfix,
      importance = TRUE,
      ntree = ntree
    )
  }

# GiniDecreaseGini: Ergebnisse aus Durchgang 3
x3 <- importance(vs.rf.model_vs3, type = 2, conditional = TRUE)
importanceOrder3 <- order(-x3)
namen3 <- rownames(x3)[importanceOrder3][1:500] 

# Finale Auswahl der 30 wichtigsten erklärenden Variablen + Zielvariable, Jahr und Geschlecht
namen3_final <- rownames(x3)[importanceOrder3][1:30]
# varImpPlot(vs.rf.model_vs3, type = 2, bg = "#027180", cex=0.75, pch=21)
imp3 <- varImpPlot(vs.rf.model_vs3, type = 2, bg = "#027180", cex=0.75, pch=21)
imp3 <- as.data.frame(imp3)
imp3$varnames <- rownames(imp3)
rownames(imp3) <- NULL 
imp3<- imp3 %>%
  head(10)

rf_varimp3<- ggplot(imp3, aes(x=reorder(varnames, MeanDecreaseGini), y=MeanDecreaseGini)) + 
  geom_point() +
  geom_segment(aes(x=varnames,xend=varnames,y=0,yend=MeanDecreaseGini)) +
  theme_bw() +
  labs(
    title = "3. RF: Variablen Wichtigkeit",
    tag = "XX",
    x= "Mean Decrease Gini",
    y= "Variable Name") +
  coord_flip()

rf_varimp3

# Auswahl der besten 30 + Geschlecht + Jahr aus Datensatz
geri_vs_0<- geri_1 %>%
  select(STA_IND_STATAUFENTH_RESP1,
         VP_TFGESCHL_Z,
         JAHR,
         !!!namen3_final) %>%
  mutate_if(is.character, as.factor)

str(geri_vs_0)

## 4. Schritt: Korrelationsprüfung ##
# Korrelation mit 33 Variablen prüfen
korr_var_33 <-
  ggcorr(
    geri_vs_0,
    method = c("everything", "pearson"),
    legend.size = 2,
    # geom = "blank",
    # label = TRUE,
    hjust = 1,
    # label_size = 4,
    cex = 2
  ) +
  geom_point(size = 8, aes(color = coefficient > 0, alpha = abs(coefficient) >= 0.85)) +
  scale_alpha_manual(values = c("TRUE" = 0.25, "FALSE" = 0)) +
  guides(color = FALSE, alpha = FALSE) +
  labs(
    title = "33 Var: Korrelationskoeffizient nach Pearson",
    caption = "Fig. 3: 33 Var: Korrelationskoeffizient nach Pearson"
  )

korr_var_33

# Kontrolle: starke Korrelationen (ab 0.85) werden entfernt
descrCor <-  (round(cor(geri_vs_0), 2))
vor_Prüfung <- summary(descrCor[upper.tri(descrCor)])

highlyCorDescr <- findCorrelation(descrCor, cutoff = .85)
geri_vs_1 <- geri_vs_0[, -highlyCorDescr]

descrCor2 <- (round(cor(geri_vs_1), 2))
nach_Prüfung <- summary(descrCor2[upper.tri(descrCor2)])

# nach Korrelationsprüfung: 19 erklärende Variablen + Response: 20 Var.
Korrelation_Korrektur<- rbind(vor_Prüfung, nach_Prüfung)

Korrelation <- kable(Korrelation_Korrektur, caption = "Fig.4: Korrelationsprüfung") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  row_spec(0:0, align = T, underline = T)

Korrelation

# Korrelation mit 20 Variablen prüfen
korr_var_20 <-
  ggcorr(
    geri_vs_1,
    method = c("everything", "pearson"),
    legend.size = 2,
    # geom = "blank",
    # label = TRUE,
    hjust = 1,
    # label_size = 4,
    cex = 2
  ) +
  geom_point(size = 9, aes(color = coefficient > 0, alpha = abs(coefficient) >= 0.85)) +
  scale_alpha_manual(values = c("TRUE" = 0.25, "FALSE" = 0)) +
  guides(color = FALSE, alpha = FALSE) +
  labs(
    title = "20 Var: Korrelationskoeffizient nach Pearson",
    caption = "Fig. 32: 20 Var: Korrelationskoeffizient nach Pearson"
  )

korr_var_20

## wegen instabiler Umsetzung wird mit set.seed Resultat (2022) weiter gemacht ##
geri_vs_0 <- geri_1 %>%
  select(
    STA_IND_STATAUFENTH_RESP1,
    JAHR,
    VP_TFGESCHL_Z,
    VP_ALTER,
    VP_DAUER_VP,
    VP_MBT,
    LST_BLGREBTR_1_GESAMT,
    LST_BLGREBTR_1_AMBARZT,
    LST_LPAESBTR_1_GESAMT,
    LST_LPAESBTR_1_AMBGES,
    LST_LPAESBTR_1_AMBARZT,
    LST_LPAESBTR_1_ZAHNGES,
    LST_LPAESBTR_1_MEDI,
    LST_ANTBELEG_1_MEDI,
    ICDALLE_CHRONISCHE_KRANKHEIT,
    ICDALLE_IX,
    PZN_GESAMT_1_ANZEINH,
    PZN_PRISCUS_0_ANZST,
    PZN_ATC_1_C_RB,
    FRT_ANZ_FACHRICH_GES
    
  ) %>%
  mutate_if(is.character, as.factor)

str(geri_vs_0)

##### 3.2 Datenmanipulation #####
# Labeling
geri_vs_1 <- geri_vs_0 %>%
  mutate(
    STA_IND_STATAUFENTH_RESP1 = case_when(
      STA_IND_STATAUFENTH_RESP1 == 0 ~ "no",
      STA_IND_STATAUFENTH_RESP1 == 1 ~ "yes"
    ),
    VP_TFGESCHL_Z = case_when(
      VP_TFGESCHL_Z == 1 ~ "male",
      VP_TFGESCHL_Z == 2 ~ "female"
    ),
    JAHR = case_when(
      JAHR == 2014 ~ "2014",
      JAHR == 2015 ~ "2015",
      JAHR == 2016 ~ "2016",
      JAHR == 2017 ~ "2017",
      JAHR == 2018 ~ "2018"
    )
  ) %>%
  mutate_if(is.character, as.factor)

str(geri_vs_1)

# Ausreißer entfernen: Kriterium extrem außerhalb des Messbereichs
# Reduktion auf 20 Variablen & 90.629 Beobachtungen
geri_vs_2 <- geri_vs_1 %>%
  filter(LST_BLGREBTR_1_GESAMT >= 0) %>%
  filter(LST_BLGREBTR_1_GESAMT < 250000) %>%
  filter(LST_LPAESBTR_1_GESAMT >= 0) %>%
  filter(LST_LPAESBTR_1_GESAMT < 130000) %>%
  filter(LST_LPAESBTR_1_AMBGES < 100000) %>%
  filter(LST_BLGREBTR_1_AMBARZT >= 0) %>%
  filter(LST_BLGREBTR_1_AMBARZT < 70000) %>%
  filter(PZN_GESAMT_1_ANZEINH < 400000) %>%
  filter(VP_DAUER_VP >= 5) %>%
  filter(ICDALLE_CHRONISCHE_KRANKHEIT < 100) %>%
  filter(LST_LPAESBTR_1_ZAHNGES >= 0) %>%
  filter(LST_LPAESBTR_1_ZAHNGES < 20000) %>%
  filter(ICDALLE_IX < 50) %>%
  filter(PZN_ATC_1_C_RB < 2500) %>%
  filter(LST_LPAESBTR_1_MEDI >= 0) %>%
  filter(LST_LPAESBTR_1_MEDI <= 100000) %>%
  filter(PZN_PRISCUS_0_ANZST <= 30000) %>%
  filter(LST_LPAESBTR_1_AMBARZT >= 0) %>%
  filter(LST_LPAESBTR_1_AMBARZT <= 50000) %>%
  filter(LST_ANTBELEG_1_MEDI <= 150) %>%
  mutate_if(is.character, as.factor)

str(geri_vs_2)

##### 3.3 Datenexploration ####
# Anteil Zielvariable am Datensatz darstellen
plot_resp <-
  ggplot(
    data = geri_vs_2,
    aes(x = STA_IND_STATAUFENTH_RESP1, fill = "#027180"),
    width = 0.002,
    alpha = 0.07
  ) +
  geom_bar() +
  theme_bw() +
  theme(legend.position = "none") +
  geom_text(
    stat = 'count',
    aes(label = ..count..),
    vjust = 1.6,
    color = "white",
    size = 3.5
  ) +
  scale_fill_manual(values = c("#027180")) +
  labs(
    title = "Verteilung Zielvariable",
    subtitle = "stationärer Aufenthalt: yes = Minority Class",
    caption = "Fig.5: Verteilung Zielvariable",
    x = "Jahr",
    y = "Zielvariable: stationärer Aufenthalt"
  )

plot_resp

# Übersicht über alle Variablen darstellen
# Zielvariable:
Zielvariable <- cbind("", "", "")
rownames(Zielvariable) <- c("Zielvariable")

tab_resp <-
  transform(as.data.frame(table(geri_vs_2$STA_IND_STATAUFENTH_RESP1)),
            percentage_column = Freq / nrow(geri_vs_2) * 100
  )

resp_n <- format((tab_resp$Freq[1] + tab_resp$Freq[2]), big.mark = ".", scientific = FALSE)

resp_no_a <- format((tab_resp$Freq[1]), big.mark = ".", scientific = FALSE)
resp_yes_a <- format((tab_resp$Freq[2]), big.mark = ".", scientific = FALSE)

resp_no_p <-
  round(tab_resp$Freq[1] / (tab_resp$Freq[1] + tab_resp$Freq[2]) * 100) %>%
  paste("%")
resp_yes_p <-
  round(tab_resp$Freq[2] / (tab_resp$Freq[1] + tab_resp$Freq[2]) * 100) %>%
  paste("%")

resp_no <- cbind(resp_no_a, resp_no_p)
resp_no_str <- str_c(resp_no, collapse = "; ")

resp_yes <- cbind(resp_yes_a, resp_yes_p)
resp_yes_str <- str_c(resp_yes, collapse = "; ")

resp_row <- cbind(resp_n, resp_yes_str, resp_no_str)
rownames(resp_row) <- c("Stationärer Aufenthalt")

# Jahr:
Jahr <- cbind("", "", "")
rownames(Jahr) <- c("Jahr")

tab_jahr <-
  table(geri_vs_2$JAHR, geri_vs_2$STA_IND_STATAUFENTH_RESP1) %>%
  as.data.frame()

# Jahr: 2014
J2014 <- format((tab_jahr$Freq[1] + tab_jahr$Freq[6]), big.mark = ".", scientific = FALSE)

J2014_no_a <- format((tab_jahr$Freq[1]), big.mark = ".", scientific = FALSE)
J2014_yes_a <- format((tab_jahr$Freq[6]), big.mark = ".", scientific = FALSE)

J2014_no_p <-
  round(tab_jahr$Freq[1] / (tab_jahr$Freq[1] + tab_jahr$Freq[6]) * 100) %>%
  paste("%")
J2014_yes_p <-
  round(tab_jahr$Freq[6] / (tab_jahr$Freq[1] + tab_jahr$Freq[6]) * 100) %>%
  paste("%")

J2014_no <- cbind(J2014_no_a, J2014_no_p)
J2014_no_str <- str_c(J2014_no, collapse = "; ")

J2014_yes <- cbind(J2014_yes_a, J2014_yes_p)
J2014_yes_str <- str_c(J2014_yes, collapse = "; ")

J2014_row <- cbind(J2014, J2014_yes_str, J2014_no_str)
rownames(J2014_row) <- c("2014")

# Jahr: 2015
J2015 <- format((tab_jahr$Freq[2] + tab_jahr$Freq[7]), big.mark = ".", scientific = FALSE)

J2015_no_a <- format((tab_jahr$Freq[2]), big.mark = ".", scientific = FALSE)
J2015_yes_a <- format((tab_jahr$Freq[7]), big.mark = ".", scientific = FALSE)

J2015_no_p <-
  round(tab_jahr$Freq[2] / (tab_jahr$Freq[2] + tab_jahr$Freq[7]) * 100) %>%
  paste("%")
J2015_yes_p <-
  round(tab_jahr$Freq[7] / (tab_jahr$Freq[2] + tab_jahr$Freq[7]) * 100) %>%
  paste("%")

J2015_no <- cbind(J2015_no_a, J2015_no_p)
J2015_no_str <- str_c(J2015_no, collapse = "; ")

J2015_yes <- cbind(J2015_yes_a, J2015_yes_p)
J2015_yes_str <- str_c(J2015_yes, collapse = "; ")

J2015_row <- cbind(J2015, J2015_yes_str, J2015_no_str)
rownames(J2015_row) <- c("2015")

# Jahr: 2016
J2016 <- format((tab_jahr$Freq[3] + tab_jahr$Freq[8]), big.mark = ".", scientific = FALSE)

J2016_no_a <- format((tab_jahr$Freq[3]), big.mark = ".", scientific = FALSE)
J2016_yes_a <- format((tab_jahr$Freq[8]), big.mark = ".", scientific = FALSE)

J2016_no_p <-
  round(tab_jahr$Freq[3] / (tab_jahr$Freq[3] + tab_jahr$Freq[8]) * 100) %>%
  paste("%")
J2016_yes_p <-
  round(tab_jahr$Freq[8] / (tab_jahr$Freq[3] + tab_jahr$Freq[8]) * 100) %>%
  paste("%")

J2016_no <- cbind(J2016_no_a, J2016_no_p)
J2016_no_str <- str_c(J2016_no, collapse = "; ")

J2016_yes <- cbind(J2016_yes_a, J2016_yes_p)
J2016_yes_str <- str_c(J2016_yes, collapse = "; ")

J2016_row <- cbind(J2016, J2016_yes_str, J2016_no_str)
rownames(J2016_row) <- c("2016")

# Jahr: 2017
J2017 <- format((tab_jahr$Freq[4] + tab_jahr$Freq[9]), big.mark = ".", scientific = FALSE)

J2017_no_a <- format((tab_jahr$Freq[4]), big.mark = ".", scientific = FALSE)
J2017_yes_a <- format((tab_jahr$Freq[9]), big.mark = ".", scientific = FALSE)

J2017_no_p <-
  round(tab_jahr$Freq[4] / (tab_jahr$Freq[4] + tab_jahr$Freq[9]) * 100) %>%
  paste("%")
J2017_yes_p <-
  round(tab_jahr$Freq[9] / (tab_jahr$Freq[4] + tab_jahr$Freq[9]) * 100) %>%
  paste("%")

J2017_no <- cbind(J2017_no_a, J2017_no_p)
J2017_no_str <- str_c(J2017_no, collapse = "; ")

J2017_yes <- cbind(J2017_yes_a, J2017_yes_p)
J2017_yes_str <- str_c(J2017_yes, collapse = "; ")

J2017_row <- cbind(J2017, J2017_yes_str, J2017_no_str)
rownames(J2017_row) <- c("   2017")

# Jahr: 2018
J2018 <- format((tab_jahr$Freq[5] + tab_jahr$Freq[10]), big.mark = ".", scientific = FALSE)

J2018_no_a <- format((tab_jahr$Freq[5]), big.mark = ".", scientific = FALSE)
J2018_yes_a <- format((tab_jahr$Freq[10]), big.mark = ".", scientific = FALSE)

J2018_no_p <-
  round(tab_jahr$Freq[5] / (tab_jahr$Freq[5] + tab_jahr$Freq[10]) * 100) %>%
  paste("%")
J2018_yes_p <-
  round(tab_jahr$Freq[10] / (tab_jahr$Freq[5] + tab_jahr$Freq[10]) * 100) %>%
  paste("%")

J2018_no <- cbind(J2018_no_a, J2018_no_p)
J2018_no_str <- str_c(J2018_no, collapse = "; ")

J2018_yes <- cbind(J2018_yes_a, J2018_yes_p)
J2018_yes_str <- str_c(J2018_yes, collapse = "; ")

J2018_row <- cbind(J2018, J2018_yes_str, J2018_no_str)
rownames(J2018_row) <- c("2018")

## Demografische Daten ##
# Geschlecht:
Geschlecht <- cbind("", "", "")
rownames(Geschlecht) <- c("Geschlecht")

tab_geschl <-
  table(geri_vs_2$VP_TFGESCHL_Z,
        geri_vs_2$STA_IND_STATAUFENTH_RESP1) %>%
  as.data.frame()

# Geschlecht: female
female <- format((tab_geschl$Freq[1] + tab_geschl$Freq[3]), big.mark = ".", scientific = FALSE)

female_no_a <- format((tab_geschl$Freq[1]), big.mark = ".", scientific = FALSE)
female_yes_a <- format((tab_geschl$Freq[3]), big.mark = ".", scientific = FALSE)

female_no_p <-
  round(tab_geschl$Freq[1] / (tab_geschl$Freq[1] + tab_geschl$Freq[3]) *
          100) %>%
  paste("%")
female_yes_p <-
  round(tab_geschl$Freq[3] / (tab_geschl$Freq[1] + tab_geschl$Freq[3]) *
          100) %>%
  paste("%")

female_no <- cbind(female_no_a, female_no_p)
female_no_str <- str_c(female_no, collapse = "; ")

female_yes <- cbind(female_yes_a, female_yes_p)
female_yes_str <- str_c(female_yes, collapse = "; ")

female_row <- cbind(female, female_yes_str, female_no_str)
rownames(female_row) <- c("Frau")

# Geschlecht: male
male <- format((tab_geschl$Freq[2] + tab_geschl$Freq[4]), big.mark = ".", scientific = FALSE)

male_no_a <- format((tab_geschl$Freq[2]), big.mark = ".", scientific = FALSE)
male_yes_a <- format((tab_geschl$Freq[4]), big.mark = ".", scientific = FALSE)

male_no_p <-
  round(tab_geschl$Freq[2] / (tab_geschl$Freq[2] + tab_geschl$Freq[4]) *
          100) %>%
  paste("%")
male_yes_p <-
  round(tab_geschl$Freq[4] / (tab_geschl$Freq[2] + tab_geschl$Freq[4]) *
          100) %>%
  paste("%")

male_no <- cbind(male_no_a, male_no_p)
male_no_str <- str_c(male_no, collapse = "; ")

male_yes <- cbind(male_yes_a, male_yes_p)
male_yes_str <- str_c(male_yes, collapse = "; ")

male_row <- cbind(male, male_yes_str, male_no_str)
rownames(male_row) <- c("Mann")

# VP_ALTER
VP_ALTER_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(VP_ALTER)) %>%
  as.data.frame()

VP_ALTER_tab_yes <- round(VP_ALTER_tab$avg[2])
VP_ALTER_tab_no <- round(VP_ALTER_tab$avg[1])
VP_ALTER_row <- cbind("", VP_ALTER_tab_yes, VP_ALTER_tab_no)
rownames(VP_ALTER_row) <- c("Alter")

# VP_DAUER_VP
VP_DAUER_VP_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(VP_DAUER_VP)) %>%
  as.data.frame()

VP_DAUER_VP_tab_yes <- round(VP_DAUER_VP_tab$avg[2])
VP_DAUER_VP_tab_no <- round(VP_DAUER_VP_tab$avg[1])
VP_DAUER_VP_row <- cbind("", VP_DAUER_VP_tab_yes, VP_DAUER_VP_tab_no)
rownames(VP_DAUER_VP_row) <- c("Versichertendauer")

# VP_MBT
VP_MBT_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(VP_MBT)) %>%
  as.data.frame()

VP_MBT_tab_yes <- round(VP_MBT_tab$avg[2])
VP_MBT_tab_no <- round(VP_MBT_tab$avg[1])
VP_MBT_row <- cbind("", VP_MBT_tab_yes, VP_MBT_tab_no)
rownames(VP_MBT_row) <- c("Monatsbeitrag")

# Leistungsdaten nach Leistungsart:
# LST_BLGREBTR_1_GESAMT
LST_BLGREBTR_1_GESAMT_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_BLGREBTR_1_GESAMT)) %>%
  as.data.frame()
female <- format((tab_geschl$Freq[1] + tab_geschl$Freq[3]), big.mark = ".", scientific = FALSE)

LST_BLGREBTR_1_GESAMT_tab_yes <-
  format((round(LST_BLGREBTR_1_GESAMT_tab$avg[2])), big.mark = ".", scientific = FALSE)
LST_BLGREBTR_1_GESAMT_tab_no <-
  format((round(LST_BLGREBTR_1_GESAMT_tab$avg[1])), big.mark = ".", scientific = FALSE)
LST_BLGREBTR_1_GESAMT_row <-
  cbind("",
        LST_BLGREBTR_1_GESAMT_tab_yes,
        LST_BLGREBTR_1_GESAMT_tab_no)
rownames(LST_BLGREBTR_1_GESAMT_row) <- c("Rechnungsbetrag gesamt")

# LST_BLGREBTR_1_AMBARZT
LST_BLGREBTR_1_AMBARZT_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_BLGREBTR_1_AMBARZT)) %>%
  as.data.frame()

LST_BLGREBTR_1_AMBARZT_tab_yes <-
  format((round(LST_BLGREBTR_1_AMBARZT_tab$avg[2])), big.mark = ".", scientific = FALSE)
LST_BLGREBTR_1_AMBARZT_tab_no <-
  format((round(LST_BLGREBTR_1_AMBARZT_tab$avg[1])), big.mark = ".", scientific = FALSE)
LST_BLGREBTR_1_AMBARZT_row <-
  cbind("",
        LST_BLGREBTR_1_AMBARZT_tab_yes,
        LST_BLGREBTR_1_AMBARZT_tab_no)
rownames(LST_BLGREBTR_1_AMBARZT_row) <-
  c("Rechnungsbetrag ambulanter Arzt")

# LST_LPAESBTR_1_GESAMT
LST_LPAESBTR_1_GESAMT_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_LPAESBTR_1_GESAMT)) %>%
  as.data.frame()

LST_LPAESBTR_1_GESAMT_tab_yes <-
  format((round(LST_LPAESBTR_1_GESAMT_tab$avg[2])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_GESAMT_tab_no <-
  format((round(LST_LPAESBTR_1_GESAMT_tab$avg[1])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_GESAMT_row <-
  cbind("",
        LST_LPAESBTR_1_GESAMT_tab_yes,
        LST_LPAESBTR_1_GESAMT_tab_no)
rownames(LST_LPAESBTR_1_GESAMT_row) <- c("Erstattungsbetrag gesamt")

# LST_LPAESBTR_1_AMBGES
LST_LPAESBTR_1_AMBGES_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_LPAESBTR_1_AMBGES)) %>%
  as.data.frame()

LST_LPAESBTR_1_AMBGES_tab_yes <-
  format((round(LST_LPAESBTR_1_AMBGES_tab$avg[2])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_AMBGES_tab_no <-
  format((round(LST_LPAESBTR_1_AMBGES_tab$avg[1])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_AMBGES_row <-
  cbind("",
        LST_LPAESBTR_1_AMBGES_tab_yes,
        LST_LPAESBTR_1_AMBGES_tab_no)
rownames(LST_LPAESBTR_1_AMBGES_row) <-
  c("Erstattungsbetrag ambulant")

# LST_LPAESBTR_1_AMBARZT
LST_LPAESBTR_1_AMBARZT_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_LPAESBTR_1_AMBARZT)) %>%
  as.data.frame()

LST_LPAESBTR_1_AMBARZT_tab_yes <-
  format((round(LST_LPAESBTR_1_AMBARZT_tab$avg[2])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_AMBARZT_tab_no <-
  format((round(LST_LPAESBTR_1_AMBARZT_tab$avg[1])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_AMBARZT_row <-
  cbind("",
        LST_LPAESBTR_1_AMBARZT_tab_yes,
        LST_LPAESBTR_1_AMBARZT_tab_no)
rownames(LST_LPAESBTR_1_AMBARZT_row) <-
  c("Erstattungsbetrag ambulanter Arzt")

# LST_LPAESBTR_1_ZAHNGES
LST_LPAESBTR_1_ZAHNGES_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_LPAESBTR_1_ZAHNGES)) %>%
  as.data.frame()

LST_LPAESBTR_1_ZAHNGES_tab_yes <-
  format((round(LST_LPAESBTR_1_ZAHNGES_tab$avg[2])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_ZAHNGES_tab_no <-
  format((round(LST_LPAESBTR_1_ZAHNGES_tab$avg[1])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_ZAHNGES_row <-
  cbind("",
        LST_LPAESBTR_1_ZAHNGES_tab_yes,
        LST_LPAESBTR_1_ZAHNGES_tab_no)
rownames(LST_LPAESBTR_1_ZAHNGES_row) <- c("Erstattungsbetrag Zahn")

# LST_LPAESBTR_1_MEDI
LST_LPAESBTR_1_MEDI_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_LPAESBTR_1_MEDI)) %>%
  as.data.frame()

LST_LPAESBTR_1_MEDI_tab_yes <- format((round(LST_LPAESBTR_1_MEDI_tab$avg[2])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_MEDI_tab_no <- format((round(LST_LPAESBTR_1_MEDI_tab$avg[1])), big.mark = ".", scientific = FALSE)
LST_LPAESBTR_1_MEDI_row <-
  cbind("", LST_LPAESBTR_1_MEDI_tab_yes, LST_LPAESBTR_1_MEDI_tab_no)
rownames(LST_LPAESBTR_1_MEDI_row) <-
  c("Erstattungsbetrag Medikamente")

# Belege nach Leistungsarten:
# LST_ANTBELEG_1_MEDI
LST_ANTBELEG_1_MEDI_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(LST_ANTBELEG_1_MEDI)) %>%
  as.data.frame()

LST_ANTBELEG_1_MEDI_tab_yes <- round(LST_ANTBELEG_1_MEDI_tab$avg[2])
LST_ANTBELEG_1_MEDI_tab_no <- round(LST_ANTBELEG_1_MEDI_tab$avg[1])
LST_ANTBELEG_1_MEDI_row <-
  cbind("", LST_ANTBELEG_1_MEDI_tab_yes, LST_ANTBELEG_1_MEDI_tab_no)
rownames(LST_ANTBELEG_1_MEDI_row) <- c("Beleganzahl Medikamente")

# Erkrankungen:
# ICDALLE_CHRONISCHE_KRANKHEIT
ICDALLE_CHRONISCHE_KRANKHEIT_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(ICDALLE_CHRONISCHE_KRANKHEIT)) %>%
  as.data.frame()

ICDALLE_CHRONISCHE_KRANKHEIT_tab_yes <-
  round(ICDALLE_CHRONISCHE_KRANKHEIT_tab$avg[2])
ICDALLE_CHRONISCHE_KRANKHEIT_tab_no <-
  round(ICDALLE_CHRONISCHE_KRANKHEIT_tab$avg[1])
ICDALLE_CHRONISCHE_KRANKHEIT_row <-
  cbind("",
        ICDALLE_CHRONISCHE_KRANKHEIT_tab_yes,
        ICDALLE_CHRONISCHE_KRANKHEIT_tab_no)
rownames(ICDALLE_CHRONISCHE_KRANKHEIT_row) <-
  c("Beleganzahl chronische Erkrankungen")

# ICDALLE_IX
ICDALLE_IX_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(ICDALLE_IX)) %>%
  as.data.frame()

ICDALLE_IX_tab_yes <- round(ICDALLE_IX_tab$avg[2])
ICDALLE_IX_tab_no <- round(ICDALLE_IX_tab$avg[1])
ICDALLE_IX_row <- cbind("", ICDALLE_IX_tab_yes, ICDALLE_IX_tab_no)
rownames(ICDALLE_IX_row) <- c("Beleganzahl ICDIX")

# Medikamente:
# PZN_GESAMT_1_ANZEINH
PZN_GESAMT_1_ANZEINH_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(PZN_GESAMT_1_ANZEINH)) %>%
  as.data.frame()

PZN_GESAMT_1_ANZEINH_tab_yes <-
  format((round(PZN_GESAMT_1_ANZEINH_tab$avg[2])), big.mark = ".", scientific = FALSE)
PZN_GESAMT_1_ANZEINH_tab_no <- format((round(PZN_GESAMT_1_ANZEINH_tab$avg[1])), big.mark = ".", scientific = FALSE)
PZN_GESAMT_1_ANZEINH_row <-
  cbind("",
        PZN_GESAMT_1_ANZEINH_tab_yes,
        PZN_GESAMT_1_ANZEINH_tab_no)
rownames(PZN_GESAMT_1_ANZEINH_row) <- c("Menge Medikamente")

# PZN_PRISCUS_0_ANZST
PZN_PRISCUS_0_ANZST_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(PZN_PRISCUS_0_ANZST)) %>%
  as.data.frame()

PZN_PRISCUS_0_ANZST_tab_yes <- format((round(PZN_PRISCUS_0_ANZST_tab$avg[2])), big.mark = ".", scientific = FALSE)
PZN_PRISCUS_0_ANZST_tab_no <- format((round(PZN_PRISCUS_0_ANZST_tab$avg[1])), big.mark = ".", scientific = FALSE)
PZN_PRISCUS_0_ANZST_row <-
  cbind("", PZN_PRISCUS_0_ANZST_tab_yes, PZN_PRISCUS_0_ANZST_tab_no)
rownames(PZN_PRISCUS_0_ANZST_row) <- c("Menge Priscusmedikamente")

# PZN_ATC_1_C_RB
PZN_ATC_1_C_RB_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(PZN_ATC_1_C_RB)) %>%
  as.data.frame()

PZN_ATC_1_C_RB_tab_yes <- round(PZN_ATC_1_C_RB_tab$avg[2])
PZN_ATC_1_C_RB_tab_no <- round(PZN_ATC_1_C_RB_tab$avg[1])
PZN_ATC_1_C_RB_row <-
  cbind("", PZN_ATC_1_C_RB_tab_yes, PZN_ATC_1_C_RB_tab_no)
rownames(PZN_ATC_1_C_RB_row) <- c("Rechnungsbetrag PZN: ATC 1C")

# Fachrichtungen:
# FRT_ANZ_FACHRICH_GES
FRT_ANZ_FACHRICH_GES_tab <- geri_vs_2 %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n(),
            avg = mean(FRT_ANZ_FACHRICH_GES)) %>%
  as.data.frame()

FRT_ANZ_FACHRICH_GES_tab_yes <-
  round(FRT_ANZ_FACHRICH_GES_tab$avg[2])
FRT_ANZ_FACHRICH_GES_tab_no <-
  round(FRT_ANZ_FACHRICH_GES_tab$avg[1])
FRT_ANZ_FACHRICH_GES_row <-
  cbind("",
        FRT_ANZ_FACHRICH_GES_tab_yes,
        FRT_ANZ_FACHRICH_GES_tab_no)

rownames(FRT_ANZ_FACHRICH_GES_row) <-
  c("Anzahl verschiedener Fachrichtungen")

# Tabelle zusammensetzen
Variablen <- cbind("[n]", "[n, % / avg]", "[n, % / avg]")
rownames(Variablen) <- c("")

Variablen_ges <- rbind(
  Variablen,
  
  #Zielvariable,
  resp_row,
  Jahr,
  J2014_row,
  J2015_row,
  J2016_row,
  J2017_row,
  J2018_row,
  
  ## Demografische Daten ##
  Geschlecht,
  female_row,
  male_row,
  VP_ALTER_row,
  VP_DAUER_VP_row,
  VP_MBT_row,
  
  ## Leistungsausgaben nach Leistungsart ##
  LST_BLGREBTR_1_GESAMT_row,
  LST_BLGREBTR_1_AMBARZT_row,
  LST_LPAESBTR_1_GESAMT_row,
  LST_LPAESBTR_1_AMBGES_row,
  LST_LPAESBTR_1_AMBARZT_row,
  LST_LPAESBTR_1_ZAHNGES_row,
  LST_LPAESBTR_1_MEDI_row,
  
  # Belege nach Leistungsart
  LST_ANTBELEG_1_MEDI_row,
  
  # Erkrankungen
  ICDALLE_CHRONISCHE_KRANKHEIT_row,
  ICDALLE_IX_row,
  
  # Medikamente
  PZN_GESAMT_1_ANZEINH_row,
  PZN_PRISCUS_0_ANZST_row,
  PZN_ATC_1_C_RB_row,
  
  # Fachrichtung
  FRT_ANZ_FACHRICH_GES_row
  
) %>%
  as.data.frame()

colnames(Variablen_ges) <- c("Anzahl", "Stationär: ja", "Stationär: nein") 

Var_Übersicht <- kable(Variablen_ges, caption = "Fig.6: Variablenübersicht") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  pack_rows("Zielvariable", 2, 2) %>%
  pack_rows("Zeit", 3, 8) %>%
  pack_rows("", 4, 8) %>%
  pack_rows("demografische Daten", 9, 14) %>%
  pack_rows("", 10, 11) %>%
  pack_rows("Leistungsausgaben nach Leistungsart", 15, 21) %>%
  pack_rows("Belege nach Leistungsart", 22, 22) %>%
  pack_rows("Erkrankungen", 23, 24) %>%
  pack_rows("Medikamente", 25, 27) %>%
  pack_rows("Fachrichtungen", 28, 28) 

Var_Übersicht

# Variablen für Darstellungen umbenennen
geri_vs_namen<- geri_vs_2 %>% 
  rename(stationärer.Aufenthalt = STA_IND_STATAUFENTH_RESP1) %>%
  rename(Geschlecht = VP_TFGESCHL_Z) %>%
  rename(Alter = VP_ALTER)

# Verteilung Alter nach Geschlecht
plot_alter_mw <-
  ggplot(
    geri_vs_namen,
    aes(x = Alter, fill = Geschlecht, alpha = 0.01),
    width = 0.002,
    alpha = 0.07
  ) +
  geom_density() +
  theme_bw() +
  scale_fill_manual(values = c("#027180", "#9FBEAF")) +
  labs(
    title = "Verteilung Alter und Geschlecht",
    subtitle = "gruppiert nach Geschlecht",
    caption = "Fig.33: Verteilung Alter und Geschlecht",
    x = "Alter"
  )

plot_alter_mw

# Verteilung RB
# Erweiterung auf 2019 mit errechneter med. Inflation von 4,9%
übersicht_rb <- geri_vs_namen %>%
  group_by(stationärer.Aufenthalt, JAHR) %>%
  summarise(
    count = n(),
    avg = mean(LST_BLGREBTR_1_GESAMT)
  ) %>%
  as.data.frame()

# Werte für 2019, mit Annahme, das medizinische Inflation 2019 bei 4,9% lag
rb_no_2018 <- übersicht_rb$avg[5] %>%
  as.numeric()

rb_no_2019 <- rb_no_2018 * 1.049

rb_yes_2018 <- übersicht_rb$avg[10] %>%
  as.numeric()

rb_yes_2019 <- rb_yes_2018 * 1.049

# Tabelle RB 2019
rb_2019 <- data.frame(
  "stationärer.Aufenthalt" = c("no", "yes"),
  "JAHR" = c("2019", "2019"),
  "count" = c("NA", "NA"),
  "avg" = c(rb_no_2019, rb_yes_2019)
)

# Tabellen verbinden
übersicht_rb_2019 <- rbind(übersicht_rb, rb_2019) %>%
  as.data.frame()

plot_RB <-
  ggplot(übersicht_rb_2019,
          aes(JAHR, avg),
          width = 0.002,
          alpha = 0.07
  ) +
  geom_bar(aes(fill = stationärer.Aufenthalt),
           stat = "identity",
           position = "dodge"
  ) +
  geom_smooth(aes(x = JAHR, y = avg),
              method = lm,
              colour = "black"
  ) +
  theme_bw() +
  scale_fill_manual(values = c("#027180", "#9FBEAF")) +
  labs(
    title = "Entwicklung durchschnittlicher Rechnungsbetrag",
    subtitle = "gruppiert nach Zielvariable",
    caption = "Fig.7: Entwicklung durchschnittlicher Rechnungsbetrag",
    x = "Jahr",
    y = "durchschnittlicher Rechnungsbetrag"
  )

plot_RB

# Entwicklung chronische Erkrankungen
plot_gesund <-
  ggplot(
    geri_vs_namen,
    aes(x = stationärer.Aufenthalt, y = ICDALLE_CHRONISCHE_KRANKHEIT),
    width = 0.002,
    alpha = 0.07
  ) +
  geom_boxplot(aes(fill = stationärer.Aufenthalt)) +
  facet_wrap(~JAHR) +
  theme_bw() +
  scale_fill_manual(values = c("#027180", "#9FBEAF")) +
  labs(
    title = "Belege mit chronischen Erkrankungen pro Jahr",
    subtitle = "gruppiert nach Zielvariable",
    caption = "Fig.8: Belege mit chronischen Erkrankungen pro Jahr",
    x = "Jahr",
    y = "Belege mit chronischen Erkankungen"
  )

plot_gesund

# Entwicklung Teilgruppe RB, chron. Erkrankrankungen, Alter
# Teilgruppe erstellen: 
# ab 10.000 Euro RB & ab 20 Belege mit chron. Krankheiten
# Datensatz reduziert auf 7.370 Beobachtungen
geri_cap <- geri_vs_namen %>%
  filter(LST_BLGREBTR_1_GESAMT >= 10000) %>%
  filter(ICDALLE_CHRONISCHE_KRANKHEIT > 20)

# Plot 1: RB und Erkrankungen
plot_krank_teuer <- ggplot(data = geri_cap,
                           width = 0.002,
                           alpha = 0.07) +
  geom_jitter(
    mapping = aes(
      x = ICDALLE_CHRONISCHE_KRANKHEIT,
      y = LST_BLGREBTR_1_GESAMT,
      colour = Geschlecht,
      shape = Geschlecht
    )
  ) +
  scale_color_manual(values = c("#027180", "#9FBEAF")) +
  geom_smooth(
    data = geri_cap,
    mapping = aes(x = ICDALLE_CHRONISCHE_KRANKHEIT, y = LST_BLGREBTR_1_GESAMT),
    method = lm,
    color = "#00008F"
  ) +
  theme_bw() +
  theme() +
  labs(
    title = "Chronische Erkankungen und Rechnungsbetrag",
    subtitle = "gruppiert nach Geschlecht, ab 10.000 Euro",
    caption = "Fig.9: Chronische Erkankungen und Rechnungsbetrag",
    x = "Belege mit chronischen Krankheiten",
    y = "Rechnungsbetrag"
  )

# Plot: RB und Alter
plot_alt_teuer <- ggplot(data = geri_cap,
                         width = 0.002,
                         alpha = 0.07) +
  geom_jitter(
    mapping = aes(
      x = Alter,
      y = LST_BLGREBTR_1_GESAMT,
      colour = Geschlecht,
      shape = Geschlecht
    )
  ) +
  scale_color_manual(values = c("#027180", "#9FBEAF")) +
  geom_smooth(
    data = geri_cap,
    mapping = aes(x = Alter, y = LST_BLGREBTR_1_GESAMT),
    method = lm,
    colour = "#00008F"
  ) +
  theme_bw() +
  theme()+
  labs(
    title = "Alter und Rechnungsbetrag",
    subtitle = "gruppiert nach Geschlecht, ab 10.000 Euro",
    caption = "Fig.10: Alter und Rechnungsbetrag",
    x = "Alter",
    y = "Rechnungsbetrag"
  )

plot_RB_teuer_alter <-
  gridExtra::grid.arrange(plot_krank_teuer, plot_alt_teuer, ncol = 1)

str(geri_vs_2)
##### 4. Modelle #####
# Umdrehen der Level der Responsevariable damit richtig positiv Class bei Prediction gewählt wird
geri_vs_2$STA_IND_STATAUFENTH_RESP1 <- factor(geri_vs_2$STA_IND_STATAUFENTH_RESP1, levels=rev(levels(geri_vs_2$STA_IND_STATAUFENTH_RESP1)))

geri_vs_2 <- geri_vs_2 %>%
  mutate_if(is.character, as.factor)

## 4.1 Modell-Vorbeitung ##
# Stratifizierung: 80 % Trainings- und 20% Testgruppe
set.seed(2022)
rows_train <-
  createDataPartition(
    y = geri_vs_2$STA_IND_STATAUFENTH_RESP1,
    p = .8,
    list = FALSE,
    times = 1
  )

training <- geri_vs_2[rows_train,]
test <- geri_vs_2[-rows_train,]

## 4.3 Modell-Ergebnisse ##
# Übergabe Setting:
# Resampling: 5-fache Kreuzvalidierung mit 3 Wiederholungen
# binäres Klassifikationsproblem
# Klassenwahrscheinlichkeiten
trainctrl <- caret::trainControl(
  method = "repeatedcv",
  number = 5,
  repeats = 3,
  classProbs = TRUE,
  savePredictions = TRUE,
  summaryFunction = caret::twoClassSummary
)

# RF - Modell
set.seed(2022)
rf_tree <- caret::train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "rf",
  trControl = trainctrl,
  metric = "ROC"
)

print(rf_tree)

ROC_rf_tree <- plot.roc(
  rf_tree$pred$obs,
  rf_tree$pred$yes,
  main = "ROC-Kurve: RF",
  print.auc = TRUE,
  auc.polygon = TRUE,
  auc.polygon.col = "#027180",
  print.thres = "best",
  print.thres.cex = 0.8,
  print.thres.col = "white",
  ci = T,
  quiet = T
)

# GBM - Modell
set.seed(2022)
gbm_tree <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "gbm",
  trControl = trainctrl,
  verbose = FALSE,
  metric = "ROC"
)

print(gbm_tree)

ROC_gbm_tree <- plot.roc(
  gbm_tree$pred$obs,
  gbm_tree$pred$yes,
  main = "ROC-Kurve: GBM",
  print.auc = TRUE,
  auc.polygon = TRUE,
  auc.polygon.col = "#027180",
  print.thres = "best",
  print.thres.cex = 0.8,
  print.thres.col = "white",
  ci = T,
  quiet = T
)

# GLM - Modell
set.seed(2022)
glm_fit <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "glm",
  metric = "ROC",
  family = binomial,
  trControl = trainctrl
)

print(glm_fit)

ROC_GLM <- plot.roc(
  glm_fit$pred$obs,
  glm_fit$pred$yes,
  main = "ROC-Kurve: GLM",
  print.auc = TRUE,
  auc.polygon = TRUE,
  auc.polygon.col = "#027180",
  print.thres = "best",
  print.thres.cex = 0.8,
  print.thres.col = "white",
  ci = T,
  quiet = T
)

## 4.4 Modell - Vergleich ##
# Modellvergleich über ROC
resamps <-
  resamples(list(
    RF = rf_tree,
    GBM = gbm_tree,
    GLM = glm_fit
  ))

bwplot(resamps, metric = "ROC", main = "Performance-Vergleich: RF vs. GBM vs. GLM")

##### 5. Modelloptimierung #####
## 5.1 Sample-Algorithmen ##
set.seed(2022)
down_training <- downSample(x = training[, -ncol(training)],
                            y = training$STA_IND_STATAUFENTH_RESP1)

down_training_n <- down_training %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n()) %>%
  as.data.frame()

down_n_gesamt <- format((down_training_n$count[1] * 2), big.mark = ".", scientific = FALSE)
down_n <- format((down_training_n$count[1]), big.mark = ".", scientific = FALSE)

down_row <- cbind(down_n_gesamt, down_n, down_n)
rownames(down_row) <- c("Down")

# Up-Sampling
set.seed(2022)
up_training <- upSample(x = training[, -ncol(training)],
                        y = training$STA_IND_STATAUFENTH_RESP1)

up_training_n <- up_training %>%
  group_by(STA_IND_STATAUFENTH_RESP1) %>%
  summarise(count = n()) %>%
  as.data.frame()

up_n_gesamt <- format((up_training_n$count[1] * 2), big.mark = ".", scientific = FALSE)
up_n <- format((up_training_n$count[1]), big.mark = ".", scientific = FALSE)

up_row <- cbind(up_n_gesamt, up_n, up_n)
rownames(up_row) <- c("Up")

# Sample Übersichtstabelle
sample_tab <- rbind(down_row,
                    up_row)

colnames(sample_tab) <-
  c("Anzahl gesamt", "Stationär: ja", "Stationär: nein")

Sample_Trainingsdaten <- kable(sample_tab, caption = "Fig.15: Datenübersicht: Resample Algorithmen")%>%
  kable_styling(latex_options = "striped", position = "center") %>%
  row_spec(0:0, align = T, underline = T)

Sample_Trainingsdaten

# Übergabe Settings: 
# Down-Sampling
trainctrl_d <- trainControl(
  method = "repeatedcv",
  number = 5,
  repeats = 3,
  classProbs = TRUE,
  savePredictions = TRUE,
  summaryFunction = twoClassSummary,
  sampling = "down"
)

# Up-Sampling
trainctrl_u <- trainControl(
  method = "repeatedcv",
  number = 5,
  repeats = 3,
  classProbs = TRUE,
  savePredictions = TRUE,
  summaryFunction = twoClassSummary,
  sampling = "up"
)

# Modelle erzeugen:

# RF - Modell: Down
set.seed(2022)
rf_tree_bd <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "rf",
  trControl = trainctrl_d,
  metric = "ROC"
)

print(rf_tree_bd)

# RF - Modell: Up
set.seed(2022)
rf_tree_bu <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "rf",
  trControl = trainctrl_u,
  metric = "ROC"
)

print(rf_tree_bu)

# GBM - Modell: Down
set.seed(2022)
gbm_tree_bd <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "gbm",
  trControl = trainctrl_d,
  verbose = FALSE,
  metric = "ROC"
)

print(gbm_tree_bd)

# RF - Modell: Up
set.seed(2022)
gbm_tree_bu <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "gbm",
  trControl = trainctrl_u,
  verbose = FALSE,
  metric = "ROC"
)

print(gbm_tree_bu)

set.seed(2022)
glm_fit_bd <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "glm",
  metric = "ROC",
  family = binomial,
  trControl = trainctrl_d
)

print(glm_fit_bd)

# GLM - Modell: Up
set.seed(2022)
glm_fit_bu <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "glm",
  metric = "ROC",
  family = binomial,
  trControl = trainctrl_u
)

print(glm_fit_bu)

# Vorbereitung Ergebnisübersicht: AUC-Bewertungsmetriken
options(digits = 2)
rf_d_AUC<- round((rf_tree_bd$results$ROC[1]), 2)
rf_d_sens<- round((rf_tree_bd$results$Sens[1]), 2)
rf_d_spec<- round((rf_tree_bd$results$Spec[1]), 2)
rf_u_AUC<- round((rf_tree_bu$results$ROC[1]), 2)
rf_u_sens<- round((rf_tree_bu$results$Sens[1]), 2)
rf_u_spec<- round((rf_tree_bu$results$Spec[1]), 2)

gbm_d_AUC<- round((gbm_tree_bd$results$ROC[6]), 2)
gbm_d_sens<- round((gbm_tree_bd$results$Sens[6]), 2)
gbm_d_spec<- round((gbm_tree_bd$results$Spec[6]), 2)
gbm_u_AUC<- round((gbm_tree_bu$results$ROC[9]), 2)
gbm_u_sens<- round((gbm_tree_bu$results$Sens[9]), 2)
gbm_u_spec<- round((gbm_tree_bu$results$Spec[9]), 2)

glm_d_AUC<- round((glm_fit_bd$results$ROC[1]), 2)
glm_d_sens<- round((glm_fit_bd$results$Sens[1]), 2)
glm_d_spec<- round((glm_fit_bd$results$Spec[1]), 2)
glm_u_AUC<- round((glm_fit_bu$results$ROC[1]), 2)
glm_u_sens<- round((glm_fit_bu$results$Sens[1]), 2)
glm_u_spec<- round((glm_fit_bu$results$Spec[1]), 2)

up_n_gesamt <- round((up_training_n$count[1] * 2), 2)
up_n <- round((up_training_n$count[1]), 2)

RF_sample <- rbind(rf_d_AUC, rf_d_sens, rf_d_spec, rf_u_AUC, rf_u_sens, rf_u_spec)
colnames(RF_sample) <- c("RF")

GBM_sample<- rbind(gbm_d_AUC, gbm_d_sens, gbm_d_spec, gbm_u_AUC, gbm_u_sens, gbm_u_spec)
colnames(GBM_sample) <- c("GBM")

GLM_sample<- rbind(glm_d_AUC, glm_d_sens, glm_d_spec, glm_u_AUC, glm_u_sens, glm_u_spec)
colnames(GLM_sample) <- c("GLM")

# Ergebnis-Übersicht erstellen
sample_erg <- cbind(RF_sample,
                    GBM_sample,
                    GLM_sample)

rownames(sample_erg)<- rbind("AUC", "Sensitivität", "Spezifität", "AUC", "Sensitivität", "Spezifität")
as.data.frame(sample_erg)

Sample_Ergebnisse <- kable(sample_erg, caption = "Fig.16: Ergebnisübersicht: Sample Algorithmen") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  pack_rows("Down", 1, 3) %>%
  pack_rows("Up", 4, 6)

Sample_Ergebnisse

## Sample Algorithmus: Performance-Vergleich ##
outside_models_alle <- resamples(
  list(
    unbalanciert_RF = rf_tree,
    Down_RF = rf_tree_bd,
    Up_RF = rf_tree_bu,
    
    unbalanciert_GBM = gbm_tree,
    Down_GBM = gbm_tree_bd,
    Up_gbm = gbm_tree_bu,
    
    unbalanciert_GLM = glm_fit,
    Down_GLM = glm_fit_bd,
    Up_GLM = glm_fit_bu
  )
)

# Plot über ROC Vergleich
Vergleich_Balance_alle <-
  bwplot(outside_models_alle, metric = "ROC", main = "Performance-Vergleich: Sample-Algorithmus")
Vergleich_Balance_alle

## 5.2 Hyperparameter ##
# Vorbereitung Grid Übersicht
rf_mtry<- cbind("Baumtiefe", "1 - 22")
gbm_ntrees<- cbind("Baumanzahl", "150, 200, 250")
gbm_interaction_depth<- cbind("Knotenanzahl", "6, 7, 8, 9")
gbm_shrinkage<- cbind("Lernrate", "0.01, 0.1")
gbm_nminobsinnode<- cbind("Beobachtungen pro Blatt", "7, 10, 12, 15")

Hyperparameter_tab<- rbind(rf_mtry, gbm_ntrees, gbm_interaction_depth, gbm_shrinkage, gbm_nminobsinnode)

colnames(Hyperparameter_tab) <- c("Hyperparameter", "Grid")
as.data.frame(Hyperparameter_tab)

# Tabelle zusammenfassen
Hyperparameter_Grid <- kable(Hyperparameter_tab, caption = "Fig.18: Gridübersicht: Hyperparameter") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  pack_rows("RF", 1, 1) %>%
  pack_rows("GBM", 2, 5) 

Hyperparameter_Grid

# RF Grid
rf_grid <- expand.grid(mtry = 1:(ncol(geri_vs_2) - 1))

# GBM Grid
grid_gbm <- expand.grid(
  n.trees = c(150, 200, 250),
  interaction.depth = c(6, 7, 8, 9),
  shrinkage = c(0.01, 0.1),
  n.minobsinnode = c(7, 10, 12, 15)
)

# Modelle erzeugen:
# RF - Modell: Grid Search
set.seed(2022)
rf_tree_h <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "rf",
  trControl = trainctrl,
  tuneGrid = rf_grid,
  metric = "ROC"
)

# Plot RF Hyperparameter
plot(rf_tree_h, main = "RF Hyperparameter-Performance")

# GBM - Modell: Grid Search
set.seed(2022)
gbm_tree_h <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "gbm",
  trControl = trainctrl,
  verbose = FALSE,
  tuneGrid = grid_gbm,
  metric = "ROC"
)

# GBM - Modell: Auswahl bester Hyperparameter
gbm_best_grid <- gbm_tree_h$bestTune

# balanced GBM - Modell: Grid Search
set.seed(2022)
gbm_tree_bu_h <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "gbm",
  trControl = trainctrl_u,
  verbose = FALSE,
  tuneGrid = grid_gbm,
  metric = "ROC"
)

# balanced GBM - Modell: Auswahl bester Hyperparameter
gbm_best_grid_u <- gbm_tree_bu_h$bestTune

# GBMs: Übersicht beste Hyperparamerer-Kombination
GBM_best_grid<- rbind(gbm_best_grid , gbm_best_grid_u )
colnames(GBM_best_grid)<- c("Baumanzahl", "Knotenanzahl", "Lernrate", "Beobachtungen pro Blatt")
rownames(GBM_best_grid) <- c("GBM", "up_GBM")
as.data.frame(GBM_best_grid)

GBM_Grid <- kable(GBM_best_grid, caption = "Fig.20: Hyperparameter GBM Modelle") %>%
  kable_styling(latex_options = "striped", position = "center")

GBM_Grid

# RF - Modell: Auswahl bester Hyperparameter
rf_best_grid <- rf_tree_h$bestTune

# RF - Modell: Tuning
set.seed(2022)
rf_tree_best_ob <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "rf",
  trControl = trainctrl,
  tuneGrid = rf_best_grid,
  metric = "ROC"
)

# GBM - Modell: Tuning
set.seed(2022)
gbm_tree_best_ob <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "gbm",
  trControl = trainctrl,
  verbose = FALSE,
  tuneGrid = gbm_best_grid,
  metric = "ROC"
)

# balanced GBM - Modell: Tuning
set.seed(2022)
gbm_tree_best_bu <- train(
  STA_IND_STATAUFENTH_RESP1 ~
    .,
  data = training,
  method = "gbm",
  trControl = trainctrl_u,
  verbose = FALSE,
  tuneGrid = gbm_best_grid_u,
  metric = "ROC"
)

print(gbm_tree_best_bu)

ROC_gbm_tree_best_bu <- plot.roc(
  gbm_tree_best_bu$pred$obs,
  gbm_tree_best_bu$pred$yes,
  main = "ROC-Kurve: bestes Modell",
  print.auc = TRUE,
  auc.polygon = TRUE,
  auc.polygon.col = "#027180",
  print.thres = "best",
  print.thres.cex = 0.8,
  print.thres.col = "white",
  ci = T,
  quiet = T
)

## Hyperparameter-Tuning: Performance-Vergleich ##
resamps_best <- resamples(
  list(
    RF = rf_tree,
    RF_getunt = rf_tree_best_ob,
    
    GBM = gbm_tree,
    GBM_getunt = gbm_tree_best_ob,
    
    Up_GBM = gbm_tree_bu,
    Up_GBM_getunt = gbm_tree_best_bu,
    
    GLM = glm_fit
  )
)

# Plot: Performance-Vergleich: Tuning
Modellvergleich_alle <-
  bwplot(resamps_best, metric = "ROC", main = "Performance-Vergleich: Tuning")

Modellvergleich_alle

##### 6. Ergebnisse #####
# Variablen Wichtigkeit finales Modell
gbm_vi <- plot(
  varImp(gbm_tree_best_bu, scale = T, type = 2),
  top = 6,
  xlab = "Gini Importance",
  main = "GBM - Variablen Wichtigkeit: Top 6"
)

gbm_vi

gbm_final <- gbm_tree_best_bu

# Hospitalisierungswahrscheinlichkeit vorhersagen mit Testset
gbm_final_predict <- predict(gbm_final, test)
gbm_final_CM <-
  confusionMatrix(gbm_final_predict, test$STA_IND_STATAUFENTH_RESP1)
gbm_final_d <-
  fourfoldplot(
    gbm_final_CM$table,
    color = c("#027180", "#9FBEAF"),
    conf.level = 0,
    margin = 1,
    main = "Konfusionsmatrix: bestes Modell"
  )

##### 7. Wirtschaftlichkeitsanalyse #####
## Testdatensatz mit Ergebnissen erstellen ##
# 1. Erzeugung absolute und relative prädiktive Ergebnisse
gbm_final_predict_prob <- predict(gbm_final, test, type = "prob") %>%
  as.data.frame()
gbm_final_predict_abs <- predict(gbm_final, test)

# Übergabe Ergebnisse an Testdatensatz
test_erg1 <- test

# Zuteilung: Klassifikation anspielen
Klassifikation <- gbm_final_predict
test_erg1$Klassifikation <- gbm_final_predict

# Zuteilung: Hospitalisierungswahrscheinlichkeiten anspielen
Klassifikation_prop_yes <- gbm_final_predict_prob$yes
Klassifikation_prop_no <- gbm_final_predict_prob$no
test_erg1$Klassifikation_prop_yes <- Klassifikation_prop_yes
test_erg1$Klassifikation_prop_no <- Klassifikation_prop_no

# Dataframe und Anzahl der Zeilen
test_erg1 <- as.data.frame(test_erg1)
str(test_erg1)

# Alternative
# Pred_Ergebnis<- str(test_erg1)

## großer Datensatz: Ergebnis, wegen unstabiler Umwandlung in RMarkdown exportieren ##
# write.csv(test_erg1, file = "/home/shared_folders/health_sd_analytics/analytikleistung/GesundzuHause/MDS_Abschlussarbeit/test_erg1.csv")
# 
# # Ergebnisse anspielen
# Pred_Ergebnis <- read.csv("/home/shared_folders/health_sd_analytics/analytikleistung/GesundzuHause/MDS_Abschlussarbeit/test_erg1.csv")
# Pred_Ergebnis <- data.table::data.table(Pred_Ergebnis) %>%
#   as.data.frame()

# Alternative
Pred_Ergebnis<- test_erg1

# 2. Datensatz vorbereiten
# Anteile anspielen für Gruppenzuteilung
n <- nrow(Pred_Ergebnis)
tab_test <- Pred_Ergebnis %>%
  select(STA_IND_STATAUFENTH_RESP1,
         Klassifikation,
         Klassifikation_prop_yes,
         Klassifikation_prop_no) %>%
  mutate_if(is.character, as.numeric) %>%
  mutate(ID = 1:n) %>%
  select(ID, everything())

str(tab_test)

## 3. Varianten erzeugen ##
# 1. Variante: Overall
tab_test_0 <- arrange(tab_test, desc(Klassifikation_prop_yes)) %>%
  mutate(Overall = 1) %>%
  mutate(Anteil = 1:n() / n() * 100) %>%
  select(ID, Anteil, everything()) %>%
  as.data.frame()

str(tab_test_0)

# 2. Variante: zufällige 40% aus dem Testset
set.seed(2022)
rows_random <-
  createDataPartition(
    y = tab_test$STA_IND_STATAUFENTH_RESP1,
    p = .4,
    list = FALSE,
    times = 1
  )

# zufällige Zeilen auswählen
random_test <- tab_test[rows_random,] %>%
  mutate(random_40 = 1)

str(random_test)

# 3. Variante: besten 40% aus dem Testset
# Klassifikation_prop_yes absteigend sortieren
tab_test2 <- tab_test_0 %>%
  filter(Anteil <= 40.0) %>%
  mutate(best_40 = 1)

# Varianten in einen Datensatz zusammenfassen
# Besten 40% anspielen
tab_join_1 <- left_join(x = tab_test_0, y = tab_test2, by = "ID") %>%
  select(
    ID,
    Anteil.x,
    STA_IND_STATAUFENTH_RESP1.x,
    Klassifikation_prop_yes.x,
    Klassifikation_prop_no.x,
    Klassifikation.x,
    Overall.x,
    best_40
  )

# Zufällige 40% anpielen
tab_join_2 <- left_join(x = tab_join_1, random_test, by = "ID") %>%
  select(
    ID,
    Anteil.x,
    STA_IND_STATAUFENTH_RESP1.x,
    Klassifikation_prop_yes.x,
    Klassifikation_prop_no.x,
    Klassifikation.x,
    Overall.x,
    best_40,
    random_40
  )

str(tab_join_2)

# Darstellung aller Varianten
plot_varianten <- ggplot(width = 0.002, alpha = 0.07) +
  geom_point(data = tab_join_2,
             mapping = aes(x = Anteil.x, y = Klassifikation_prop_yes.x)) +
  geom_point(
    data = tab_join_2,
    mapping = aes(
      x = Anteil.x,
      y = Klassifikation_prop_yes.x,
      color = random_40 == 1
    )
  ) +
  geom_vline(
    xintercept = 40,
    linetype = 'dashed',
    color = c("#027180"),
    size = 0.5
  ) +
  theme_bw() +
  labs(
    title = "Übersicht der 3 Varianten",
    subtitle = "Variante: 1. Overall, 2. zufällige 40%, 3. besten 40%",
    caption = "Fig.24: Übersicht der 3 Varianten",
    x = "Anteil am Testset in %",
    y = "Hospitalisierungswahrscheinlichkeit"
  )

plot_varianten

## Überblick Vierfeld Varianten ##
# Vorbereitung Zielwert-Erstellung mittels Funktion:
# Sensi, Spezi - Function:
sens.spec <- function(rp, rn, fp, fn) {
  x <- data.frame(
    sens = round(rp / (rp + fn) * 100, 0),
    spec = round(rn / (rn + fp) * 100, 0)
  )
  return(x)
}

# Die zu übergebenden Parameter sind:

# rp = Anzahl richtig positive
# rn = Anzahl richtig negative
# fp = Anzahl falsch positive
# fn = Anzahl falsch negative

# Befüllung Funktion: sens.spec(rp, rn, fp, fn)

# 1. Variante: Overall: Übergabe Vierfelder

# Alternativ
oa_vierfelder <- gbm_final_CM$table %>% as.data.frame()

## großer Datensatz: Ergebnis, wegen unstabiler Umwandlung in RMarkdown exportieren ##
# write.csv(oa_vierfelder, file = "/home/shared_folders/health_sd_analytics/analytikleistung/GesundzuHause/MDS_Abschlussarbeit/oa_vierfelder.csv")

# Ergebnisse anspielen
# oa_vierfelder <- read.csv("/home/shared_folders/health_sd_analytics/analytikleistung/GesundzuHause/MDS_Abschlussarbeit/oa_vierfelder.csv")

# oa_vierfelder <- oa_vierfelder %>%
#  select(-X)


# 2. Zielwert: Overall: Übrgabe sens.spec Function
options(digits = 2)
erg_oa <- data.frame(
  sens = c(sensitivity(gbm_final_CM$table) * 100),
  spec = c(specificity(gbm_final_CM$table) * 100)
)
erg_oa

## großer Datensatz: Ergebnis, wegen unstabiler Umwandlung in RMarkdown exportieren ##
# write.csv(erg_oa, file = "/home/shared_folders/health_sd_analytics/analytikleistung/GesundzuHause/MDS_Abschlussarbeit/erg_oa.csv")

# Ergebnisse anspielen
# erg_oa <- read.csv("/home/shared_folders/health_sd_analytics/analytikleistung/GesundzuHause/MDS_Abschlussarbeit/erg_oa.csv")

# erg_oa<- erg_oa %>%
#   select(-X)

# 1. Variante: Zufällig 40%: Übergabe Vierfelder
random_tests<- random_test %>%
  select(STA_IND_STATAUFENTH_RESP1,
         Klassifikation)

random_test2 <- random_test %>%
  mutate(
    vier_felder = case_when(
      STA_IND_STATAUFENTH_RESP1 == "yes" &
        Klassifikation == "yes"  ~ "rp",
      STA_IND_STATAUFENTH_RESP1 == "no" &
        Klassifikation == "no" ~ "rn",
      STA_IND_STATAUFENTH_RESP1 == "no" &
        Klassifikation == "yes" ~ "fp",
      STA_IND_STATAUFENTH_RESP1 == "yes" &
        Klassifikation == "no" ~ "fn"
    )
  )

table(random_test2$vier_felder)

# 2. Zielwert: Zufällig 40%: Übrgabe sens.spec Function
erg_random_40 <-
  sens.spec(length(which(random_test2$vier_felder == "rp")),
            length(which(random_test2$vier_felder == "rn")),
            length(which(random_test2$vier_felder == "fp")),
            length(which(random_test2$vier_felder == "fn")))
erg_random_40


# 1. Variante: Besten 40%: Übergabe Vierfelder
tab_test3 <- tab_test2 %>%
  mutate(
    vier_felder = case_when(
      STA_IND_STATAUFENTH_RESP1 == "yes" &
        Klassifikation == "yes"  ~ "rp",
      STA_IND_STATAUFENTH_RESP1 == "no" &
        Klassifikation == "no" ~ "rn",
      STA_IND_STATAUFENTH_RESP1 == "no" &
        Klassifikation == "yes" ~ "fp",
      STA_IND_STATAUFENTH_RESP1 == "yes" &
        Klassifikation == "no" ~ "fn"
    )
  )
table(tab_test3$vier_felder)

# 2. Zielwert: Best 40: Übrgabe sens.spec Function
erg_40 <- sens.spec(length(which(tab_test3$vier_felder == "rp")),
                    length(which(tab_test3$vier_felder == "rn")),
                    length(which(tab_test3$vier_felder == "fp")),
                    length(which(tab_test3$vier_felder == "fn")))
erg_40

# Ergebnisse aller Varianten in eine Tabelle bringen
tab_varianten_0 <- union(erg_oa, erg_40)
tab_varianten <- union(tab_varianten_0, erg_random_40) %>%
  mutate(Variante = c("Overall", "Besten 40%", "Zufällige 40%")) %>%
  select(Variante, everything())

# Variante Overall: TN Kennzeichen, Sensi, Spec
oa_richtiger_TN <- oa_vierfelder$Freq[1]
oa_falscher_NTN <- oa_vierfelder$Freq[2]
oa_falscher_TN <- oa_vierfelder$Freq[3]
oa_richtiger_NTN <- oa_vierfelder$Freq[4]
oa_sens <- round((erg_oa$sens), 2)
oa_spec <- round((erg_oa$spec), 2)

# Random 40: TN Kennzeichen, Sensi, Spec
r40_vierfelder <- data.frame(table(random_test2$vier_felder))

r40_richtiger_TN <- r40_vierfelder$Freq[4]
r40_falscher_NTN <- r40_vierfelder$Freq[1]
r40_falscher_TN <- r40_vierfelder$Freq[2]
r40_richtiger_NTN <- r40_vierfelder$Freq[3]
r40_sens <- erg_random_40$sens
r40_spec <- erg_random_40$spec

# Best 40: TN Kennzeichen, Sensi, Spec
b40_vierfelder <- data.frame(table(tab_test3$vier_felder))

b40_richtiger_TN <- b40_vierfelder$Freq[4]
b40_falscher_NTN <- b40_vierfelder$Freq[1]
b40_falscher_TN <- b40_vierfelder$Freq[2]
b40_richtiger_NTN <- b40_vierfelder$Freq[3]
b40_sens <- erg_40$sens
b40_spec <- erg_40$spec

# Varianten zusammenfassen: TN Kennzeichen, Sensi, Spec
Vierfelder_Var_1 <-
  data.frame(Variante=rbind(
    "richtiger TN",
    "falscher TN",
    "richtiger NTN",
    "falscher NTN",
    "Sensitivität (in %)",
    "Spezifität (in %)"
  ),
  Overall = c(
    format((oa_richtiger_TN), big.mark = ".", scientific = FALSE),
    format((oa_falscher_TN), big.mark = ".", scientific = FALSE),
    format((oa_richtiger_NTN), big.mark = ".", scientific = FALSE),
    format((oa_falscher_NTN), big.mark = ".", scientific = FALSE),
    round((oa_sens), 0),
    round((oa_spec), 0)
  ),
  Zufällig_40 = c(
    format((r40_richtiger_TN), big.mark = ".", scientific = FALSE),
    format((r40_falscher_TN), big.mark = ".", scientific = FALSE),
    format((r40_richtiger_NTN), big.mark = ".", scientific = FALSE),
    format((r40_falscher_NTN), big.mark = ".", scientific = FALSE),
    round((r40_sens), 0),
    round((r40_spec), 0)
  ),
  Besten_40 = c(
    format((b40_richtiger_TN), big.mark = ".", scientific = FALSE),
    format((b40_falscher_TN), big.mark = ".", scientific = FALSE),
    format((b40_richtiger_NTN), big.mark = ".", scientific = FALSE),
    format((b40_falscher_NTN), big.mark = ".", scientific = FALSE),
    round((b40_sens), 0),
    round((b40_spec), 0)
  )
  )

Vierfelder_Varianten <- kable(Vierfelder_Var_1, caption = "Fig.25: Variantenübersicht") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  pack_rows("TN Kennzeichen", 1, 4) %>%
  pack_rows("Bewertungsmetrik", 5, 6)

Vierfelder_Varianten

## Kosten ermitteln ##
# durchschnittliche Kosten für Inpatient und non Inpatient + Inflation für 2019
# Initialisierungskosten: Literaturbasiert gewählt (GKV-Zuschlag)

# Übersicht RB: aus Datenexploration
übersicht_rb_2019

# Initialisierungskosten
Initial_Kosten <- 145.32
Kostenüber_2019 <-
  data.frame(
    Kosten = c("Initialisierungskosten", "stationär", "nicht stationär"),
    In_2019 = c(Initial_Kosten, rb_yes_2019, rb_no_2019)
  )

# Kosten-Annahmen: Übersicht
rb_yes_2019_1 <- format((round(rb_yes_2018 * 1.049)), big.mark = ".", scientific = FALSE)
rb_no_2019_1 <- format((round(rb_no_2018 * 1.049)), big.mark = ".", scientific = FALSE)

Initial_Kosten_1 <- format((round(145.32)), big.mark = ".", scientific = FALSE)
Kostenüber_2019_1 <-
  data.frame(
    Kosten = c("Initialisierungskosten", "stationär", "nicht stationär"),
    In_2019 = c(Initial_Kosten_1, rb_yes_2019_1, rb_no_2019_1)
  )

Kostenübersicht_2019 <- kable(Kostenüber_2019_1, caption = "Fig.35: Annahmen: Kosten") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  row_spec(0:0, align = T, underline = T)

Kostenübersicht_2019

## Kosten-Nutzen-Übersicht erstellen ##
# Vier Gruppen und Hypothesen zu Kosten erstellen (echter RB)
# richtiger TN (rp) : Initialisierung wg Teilnahme, best Case stationärer Aufenthalt verhindert, deshalb Kosten wie non inpatient
# falscher NTN (fn) : nimmt nicht teil und kommt ins KH
# falscher TN (fp) : Initialisierungskosten wg Teilnahme, wäre aber nie ins KH gekommen
# richtiger NTN (rn) : nimmt nicht teil und kommt auch nicht ins KH

RB_richtiger_TN <-
  Kostenüber_2019$In_2019[1] + Kostenüber_2019$In_2019[3]
RB_falscher_NTN <- Kostenüber_2019$In_2019[2]
RB_falscher_TN <-
  Kostenüber_2019$In_2019[1] + Kostenüber_2019$In_2019[3]
RB_richtiger_NTN <- Kostenüber_2019$In_2019[3]

# 2b. Schritt: Viergruppen und Hypothesen zum max Savingspotenzial erstellen 
# Annahme: max. Savings, bedeutet: Krankenhaus-Aufenthalt kann vermieden werden
# richtiger TN (rp) : non Inpatient Kosten + Initalisierungskosten - Kosten für KH
# falscher NTN (fn) : Kosten für KH - non Inpatient Kosten - Initalisierungskosten
# falscher TN (fp) : Initialisierungskosten
# richtiger NTN (rn) : - Initialisierungskosten

SG_richtiger_TN <- RB_richtiger_TN - RB_falscher_NTN
SG_falscher_NTN <- RB_falscher_NTN - RB_richtiger_TN
SG_falscher_TN <- RB_falscher_TN - RB_richtiger_NTN
SG_richtiger_NTN <- RB_richtiger_NTN - RB_falscher_TN

# 3. RB und SG zusammenfassen:
RB_SG_2019_1 <-
  data.frame(
    TN_Kennzeichen = c(
      "richtiger TN",
      "falscher TN",
      "richtiger NTN",
      "falscher NTN"
    ),
    RB_2019 = c(
      format((round((RB_richtiger_TN), 0)), big.mark = ".", scientific = FALSE),
      format((round(RB_falscher_TN)), big.mark = ".", scientific = FALSE),
      format((round(RB_richtiger_NTN)), big.mark = ".", scientific = FALSE),
      format((round(RB_falscher_NTN)), big.mark = ".", scientific = FALSE)
    ),
    SG_2019 = c(
      format((round(SG_richtiger_TN)), big.mark = ".", scientific = FALSE),
      format((round(SG_falscher_TN)), big.mark = ".", scientific = FALSE),
      format((round(SG_richtiger_NTN)), big.mark = ".", scientific = FALSE),
      format((round(SG_falscher_NTN)), big.mark = ".", scientific = FALSE)
    )
  )

Kosten_Nutzen <- kable(RB_SG_2019_1, caption = "Fig.26: Kosten-Nutzen Übersicht") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  row_spec(0:0, align = T, underline = T)

Kosten_Nutzen

## Hypothese 1 ##
# Maximales Potenzial für Variante Overall und besten 40 berechnen und mit erreichbaren Savings vergleichen
# Maximales Potenzial, bedeutet optimales Modell: sensi und spec liegen bei jeweils 100%
# bedeutet nur RP und RN: Summe ist max. Savingspotenzial

# Hilfstabelle 1: Variantenübersicht
Vierfelder_Var <-
  data.frame(Variante=rbind(
    "richtiger TN",
    "falscher TN",
    "richtiger NTN",
    "falscher NTN",
    "Sensitivität (in %)",
    "Spezifität (in %)"
  ),
  overall = c(
    oa_richtiger_TN,
    oa_falscher_TN,
    oa_richtiger_NTN,
    oa_falscher_NTN,
    round((oa_sens), 0),
    round((oa_spec), 0)
  ),
  random_40 = c(
    r40_richtiger_TN,
    r40_falscher_TN,
    r40_richtiger_NTN,
    r40_falscher_NTN,
    round((r40_sens), 0),
    round((r40_spec), 0)
  ),
  best_40 = c(
    b40_richtiger_TN,
    b40_falscher_TN,
    b40_richtiger_NTN,
    b40_falscher_NTN,
    round((b40_sens), 0),
    round((b40_spec), 0)
  )
  )
Vierfelder_Var

# Hilfstabelle 2: RB-übersicht
RB_SG_2019 <-
  data.frame(
    TN_Kennzeichen = c(
      "richtiger TN",
      "falscher TN",
      "richtiger NTN",
      "falscher NTN"
    ),
    RB_2019 = c(
      RB_richtiger_TN,
      RB_falscher_TN,
      RB_richtiger_NTN,
      RB_falscher_NTN
    ),
    SG_2019 = c(
      SG_richtiger_TN,
      SG_falscher_TN,
      SG_richtiger_NTN,
      SG_falscher_NTN
    )
  )

RB_SG_2019

# 1. Maximales Potenzial
# Max. SG Potenzial: Variante Overall
ov_max_SG_TN <- format((round(((Vierfelder_Var$overall[1] + Vierfelder_Var$overall[4]) * RB_SG_2019$SG_2019[1])*0.1)), big.mark = ".", scientific = FALSE)

ov_max_SG_NTN <-
  format((round(((Vierfelder_Var$overall[2] + Vierfelder_Var$overall[3]) * RB_SG_2019$SG_2019[3])*0.1)), big.mark = ".", scientific = FALSE)

ov_max_SG_sum <- format((round((((Vierfelder_Var$overall[1] + Vierfelder_Var$overall[4]) * RB_SG_2019$SG_2019[1])+
                                  ((Vierfelder_Var$overall[2] + Vierfelder_Var$overall[3]) * RB_SG_2019$SG_2019[3]))*0.1)), big.mark = ".", scientific = FALSE)

# Max. SG Potenzial: Variante Besten 40%
b40_max_SG_TN <-
  format((round(((Vierfelder_Var$best_40[1] + Vierfelder_Var$best_40[4]) * RB_SG_2019$SG_2019[1])*0.1)), big.mark = ".", scientific = FALSE)

b40_max_SG_NTN <-
  format((round(((Vierfelder_Var$best_40[2] + Vierfelder_Var$best_40[3]) * RB_SG_2019$SG_2019[3])*0.1)), big.mark = ".", scientific = FALSE)

b40_max_SG_sum <- format((round((((Vierfelder_Var$best_40[1] + Vierfelder_Var$best_40[4]) * RB_SG_2019$SG_2019[1])+
                                   ((Vierfelder_Var$best_40[2] + Vierfelder_Var$best_40[3]) * RB_SG_2019$SG_2019[3]))*0.1)), big.mark = ".", scientific = FALSE)

# 2. Genutztes Potenzial 
# Variante: Overall 
ov_echt_SG_rTN <- (Vierfelder_Var$overall[1] * RB_SG_2019$SG_2019[1])*0.1
ov_echt_SG_fTN <- (Vierfelder_Var$overall[2] * RB_SG_2019$SG_2019[2])*0.1
ov_echt_SG_rNTN <- (Vierfelder_Var$overall[3] * RB_SG_2019$SG_2019[3])*0.1
ov_echt_SG_fNTN <- (Vierfelder_Var$overall[4] * RB_SG_2019$SG_2019[4])*0.1

ov_echt_SG_sum <-
  ov_echt_SG_rTN + ov_echt_SG_fNTN + ov_echt_SG_fTN + ov_echt_SG_rNTN

# Variante: Besten 40%
b40_echt_SG_rTN <- (Vierfelder_Var$best_40[1] * RB_SG_2019$SG_2019[1])*0.1
b40_echt_SG_fTN <- (Vierfelder_Var$best_40[2] * RB_SG_2019$SG_2019[2])*0.1
b40_echt_SG_rNTN <- (Vierfelder_Var$best_40[3] * RB_SG_2019$SG_2019[3])*0.1
b40_echt_SG_fNTN <- (Vierfelder_Var$best_40[4] * RB_SG_2019$SG_2019[4])*0.1

b40_echt_SG_sum <-
  b40_echt_SG_rTN + b40_echt_SG_fNTN + b40_echt_SG_fTN + b40_echt_SG_rNTN

# 3. Max. & genutztes Potenzial beider Varianten zusammenfassen
SG_Vgl_2019 <-
  data.frame(
    Variante = c(
      "richtiger TN",
      "falscher TN",
      "richtiger NTN",
      "falscher NTN",
      "Summe"
    ),
    Overall_SG_max. = c(ov_max_SG_TN, 0, ov_max_SG_NTN, 0, ov_max_SG_sum),
    Besten_40_SG_max. = c(b40_max_SG_TN, 0, b40_max_SG_NTN, 0, b40_max_SG_sum),
    Overall_SG = c(
      format((round(ov_echt_SG_rTN)), big.mark = ".", scientific = FALSE),
      format((round(ov_echt_SG_fTN)), big.mark = ".", scientific = FALSE),
      format((round(ov_echt_SG_rNTN)), big.mark = ".", scientific = FALSE),
      format((round(ov_echt_SG_fNTN)), big.mark = ".", scientific = FALSE),
      format((round(ov_echt_SG_sum)), big.mark = ".", scientific = FALSE)
    ),
    Besten_40_SG = c(
      format((round(b40_echt_SG_rTN)), big.mark = ".", scientific = FALSE),
      format((round(b40_echt_SG_fTN)), big.mark = ".", scientific = FALSE),
      format((round(b40_echt_SG_rNTN)), big.mark = ".", scientific = FALSE),
      format((round(b40_echt_SG_fNTN)), big.mark = ".", scientific = FALSE),
      format((round(b40_echt_SG_sum)), big.mark = ".", scientific = FALSE)
    )
  )

Erg_1_Hypothese <- kable(SG_Vgl_2019, caption = "Fig.27: Übersicht: 1. Hypothese") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  pack_rows("TN Kennzeichen", 1, 4) %>%
  pack_rows("Gesamt", 5, 5) %>%
  row_spec(0:0, align = T, underline = T)

Erg_1_Hypothese

## 2. Hypothese ##
# RB für Variante best 40 und Random 40 berechnen (ConversionRate liegt bei 10%)
# Werte aus Vierfelder-Tafel mit Kosten multiplizieren, danach addieren und vergleichen

# Variante: Zufällig 40%: Ergebnis RB
r40_SG_rTN <- format(round(((Vierfelder_Var$random_40[1] * RB_SG_2019$RB_2019[1])*0.1)), big.mark = ".", scientific = FALSE)
r40_SG_fTN <- format(round(((Vierfelder_Var$random_40[2] * RB_SG_2019$RB_2019[2])*0.1)), big.mark = ".", scientific = FALSE)
r40_SG_rNTN <- format(round(((Vierfelder_Var$random_40[3] * RB_SG_2019$RB_2019[3])*0.1)), big.mark = ".", scientific = FALSE)
r40_SG_fNTN <- format(round(((Vierfelder_Var$random_40[4] * RB_SG_2019$RB_2019[4])*0.1)), big.mark = ".", scientific = FALSE)
r40_SG_sum <- format(round((((Vierfelder_Var$random_40[1] * RB_SG_2019$RB_2019[1]) + 
                               (Vierfelder_Var$random_40[2] * RB_SG_2019$RB_2019[2]) + 
                               (Vierfelder_Var$random_40[3] * RB_SG_2019$RB_2019[3]) + 
                               (Vierfelder_Var$random_40[4] * RB_SG_2019$RB_2019[4]))*0.1)), big.mark = ".", scientific = FALSE)

# Variante: Besten 40%: Ergebnis RB
b40_SG_rTN <- format(round(((Vierfelder_Var$best_40[1] * RB_SG_2019$RB_2019[1])*0.1)), big.mark = ".", scientific = FALSE)
b40_SG_fTN <- format(round(((Vierfelder_Var$best_40[2] * RB_SG_2019$RB_2019[2])*0.1)), big.mark = ".", scientific = FALSE)
b40_SG_rNTN <- format(round(((Vierfelder_Var$best_40[3] * RB_SG_2019$RB_2019[3])*0.1)), big.mark = ".", scientific = FALSE)
b40_SG_fNTN <- format(round(((Vierfelder_Var$best_40[4] * RB_SG_2019$RB_2019[4])*0.1)), big.mark = ".", scientific = FALSE)
b40_SG_sum <- format(round((((Vierfelder_Var$best_40[1] * RB_SG_2019$RB_2019[1]) + 
                               (Vierfelder_Var$best_40[2] * RB_SG_2019$RB_2019[2]) +
                               (Vierfelder_Var$best_40[3] * RB_SG_2019$RB_2019[3]) +
                               (Vierfelder_Var$best_40[4] * RB_SG_2019$RB_2019[4]))*0.1)), big.mark = ".", scientific = FALSE)

RB_40_2019 <-
  data.frame(
    Variante = c(
      "richtiger TN",
      "falscher TN",
      "richtiger NTN",
      "falscher NTN",
      "Summe"
    ),
    RB_Zufällig_40 = c(r40_SG_rTN, r40_SG_fTN, r40_SG_rNTN, r40_SG_fNTN, r40_SG_sum),
    RB_Besten_40 = c(b40_SG_rTN, b40_SG_fTN, b40_SG_rNTN, b40_SG_fNTN, b40_SG_sum)
  )
RB_40_2019

Erg_2_Hypothese <- kable(RB_40_2019, caption = "Fig.28: Übersicht: 2. Hypothese") %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  pack_rows("TN Kennzeichen", 1, 4) %>%
  pack_rows("Gesamt", 5, 5) %>%
  row_spec(0:0, align = T, underline = T)

Erg_2_Hypothese

##### 8. Limitation #####

##### 9. Fazit #####

##### Abbildungsverzeichnis #####
Fig_no <- c(1:35)
Abbildung <- c(
  "Variablenkategorien und Inhalte",
  "RF 3: Variablen Wichtigkeit",
  "33 Var: Korrelationskoeffizient nach Pearson",
  "Korrelationsprüfung",
  "Verteilung Zielvariable",
  "Variablenübersicht",
  "Entwicklung durchschnittlicher Rechnungsbetrag",
  "Belege mit chronischen Erkrankungen pro Jahr",
  "Chronische Erkankungen und Rechnungsbetrag",
  "Alter und Rechnungsbetrag",
  "ROC-Kurve: RF",
  "ROC-Kurve: GBM",
  "ROC-Kurve: GLM",
  "Modellvergleich: RF vs GLM vs GLM",
  "Datenübersicht: Sample Algorithmen",
  "Ergebnisübersicht: Sample Algorithmen",
  "Performance-Vergleich: Sample-Algorithmus",
  "Gridübersicht: Hyperparameter",
  "RF Hyperparameter-Performance",
  "Hyperparameter GBM Modelle",
  "Modell-Vergleich: RF, GBMs, GLM",
  "Gini Importance",
  "Konfusionsmatrix: getuntes GBM",
  "Übersicht der 3 Varianten",
  "Variantenübersicht",
  "Kosten-Nutzen Übersicht",
  "Übersicht: 1. Hypothese",
  "Übersicht: 1. Hypothese",
  "Anzahl Missings pro Variable, ersten 10 von 1.119 Variablen",
  "RF 1: Variablen Wichtigkeit",
  "RF 2: Variablen Wichtigkeit",
  "20 Var: Korrelationskoeffizient nach Pearson",
  "Verteilung Alter und Geschlecht",
  "ROC-Kurve: bestes Modell",
  "Annahmen: Kosten"
)

Abb <- cbind(Fig_no, Abbildung)
Abbildungsverzeichnis <- kable(Abb) %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  row_spec(0:0, align = T, underline = T)

##### Abkürzungsverzeichnis #####
Abkürzung <- c(
  "ATC",
  "AUC",
  "COPD",
  "DMP",
  "GBM",
  "GKV",
  "GLM",
  "GzH",
  "ICD-10-GM",
  "KHK",
  "KPI",
  "MCAR",
  "MDG",
  "Mio.",
  "MSE",
  "NTN",
  "PIM",
  "PKV",
  "PZN",
  "RB",
  "RF",
  "ROC",
  "SG",
  "TN",
  "VP"
)

Bezeichnung <-
  c(
    "Anatomisch-Therapeutischen-Chemischen Klassifikation",
    "Area under the curve",
    "chronisch obstriktive Lungenerkrankung",
    "Disease Management Programm",
    "stochastisches Gradienten Boosting",
    "gesetzliche Krankenversicherung",
    "generalisiertes lineares Modell",
    "Gesund zu Hause",
    "internationale statistische Klassifikation der Krankheiten und verwandter Gesundheitsprobleme, German Modification",
    "koronare Herzkrankheit",
    "Key Performance Indikator",
    "Missing completely at random",
    "Mean Decrease Gini",
    "Millionen",
    "mittlere quadratische Vorhersagefehler",
    "nicht-Teilnehmer*in",
    "potenziell inadäquate Medikation im Alter",
    "private Krankenversichern",
    "Pharmazentralnummer",
    "Rechnungsbetrag",
    "Random Forest",
    "Receiver-Overating-Characteristics",
    "Savings",
    "Teilnehmer*in",
    "versicherte Person"
  )

Abk <- cbind(Abkürzung, Bezeichnung)
Abkürzungsverzeichnis <- kable(Abk) %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  row_spec(0:0, align = T, underline = T)

Abkürzungsverzeichnis




###### NOCH HINZUFÜGEN #####
install.packages("remotes")
library(grateful)
sessionInfo()
help("sessionInfo")

```{r }
pkgs <- cite_packages(output = "table")
R.Packages<- kable(pkgs) %>%
  kable_styling(latex_options = "striped", position = "center") %>%
  row_spec(0:0, align = T, underline = T)
```


##### Docker ####









